package parsers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NYSEParser {
	//A,01-Jan-2009,15.63,15.63,15.63,15.63,0
	
	private String symbol;
	private String tradeDate;
	private Float openPrice;
	private Float highPrice;
	private Float lowPrice;
	private Float closePrice;
	private Long volume;
	
	public void parse(String record){
		String[] field=record.split("\\,");
		symbol=field[0];
		tradeDate=field[1];
		openPrice=new Float(field[2]);
		highPrice=new Float(field[3]);
		lowPrice=new Float(field[4]);
		closePrice=new Float(field[5]);
		volume=new Long(field[6]);
		
	}
	
	public String getTradeMonth(){
		//A,01-Jan-2009,15.63,15.63,15.63,15.63,0
		SimpleDateFormat originalDate=new SimpleDateFormat("dd-MMM-yyyy");
		SimpleDateFormat targetDate=new SimpleDateFormat("MMM-yyyy");
		
		Date date=new Date();
		try {
			date=originalDate.parse(this.getTradeDate());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String target= targetDate.format(date);
		
		return target;
		
	}
	
	public String getSymbolAndMonth(){
		return symbol.concat(getTradeMonth());
	}
	
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	public Float getOpenPrice() {
		return openPrice;
	}
	public void setOpenPrice(Float openPrice) {
		this.openPrice = openPrice;
	}
	public Float getHighPrice() {
		return highPrice;
	}
	public void setHighPrice(Float highPrice) {
		this.highPrice = highPrice;
	}
	public Float getLowPrice() {
		return lowPrice;
	}
	public void setLowPrice(Float lowPrice) {
		this.lowPrice = lowPrice;
	}
	public Float getClosePrice() {
		return closePrice;
	}
	public void setClosePrice(Float closePrice) {
		this.closePrice = closePrice;
	}
	public Long getVolume() {
		return volume;
	}
	public void setVolume(Long volume) {
		this.volume = volume;
	}
	
	

}
