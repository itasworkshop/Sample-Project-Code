package com.StockData;

import keyvalues.LongPair;
import keyvalues.TextPair;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.reduce.IntSumReducer;
import org.apache.hadoop.mapreduce.lib.reduce.LongSumReducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class NYSEDriver extends Configured implements Tool {

	public static void main(String[] args) throws Exception {
		int exit = ToolRunner.run(new NYSEDriver(), args);

		System.exit(exit);
	}

	public int run(String[] arg0) throws Exception {
		// TODO Auto-generated method stub

		Job job = Job.getInstance(getConf(), "NYSECount");
		job.setJarByClass(getClass());

		TextInputFormat.addInputPath(job, new Path(arg0[0]));
		job.setInputFormatClass(TextInputFormat.class);

		TextOutputFormat.setOutputPath(job, new Path(arg0[1]));
		job.setOutputFormatClass(TextOutputFormat.class);

		job.setMapperClass(AvgStockVolPerMonthMapper.class);
		job.setReducerClass(AvgStockVolPerMonthReducer.class);
		
		job.setMapOutputKeyClass(TextPair.class);
		job.setMapOutputValueClass(LongPair.class);
		
		job.setOutputKeyClass(TextPair.class);
		job.setOutputValueClass(LongPair.class);

		return job.waitForCompletion(true) ? 0 : 1;
	}

}