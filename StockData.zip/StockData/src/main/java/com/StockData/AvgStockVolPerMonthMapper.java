package com.StockData;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import parsers.NYSEParser;

public class AvgStockVolPerMonthMapper extends Mapper<LongWritable, Text, Text, LongWritable> {

	private static NYSEParser nyseParser= new NYSEParser();
	
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		
		nyseParser.parse(value.toString());
		System.out.println(nyseParser.getSymbol());
		context.write(new Text(nyseParser.getSymbolAndMonth()), new LongWritable(nyseParser.getVolume()));
	}
}
