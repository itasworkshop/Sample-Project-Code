package com.StockData;

import java.io.IOException;

import keyvalues.LongPair;
import keyvalues.TextPair;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import parsers.NYSEParser;

public class AvgStockVolPerMonthMapper extends Mapper<LongWritable, Text, TextPair, LongPair> {

	private static NYSEParser nyseParser= new NYSEParser();
	private static TextPair textPair= new TextPair();
	private static LongPair longPair= new LongPair();
	
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		
		nyseParser.parse(value.toString());
		
		textPair.setFirst(new Text(nyseParser.getSymbol()));
		textPair.setSecond(new Text(nyseParser.getTradeMonth()));
		
		longPair.setFirst(new LongWritable(nyseParser.getVolume()));
		longPair.setSecond(new LongWritable(1));
		
		System.out.println(nyseParser.getSymbol());
		context.write(textPair, longPair);
	}
}
