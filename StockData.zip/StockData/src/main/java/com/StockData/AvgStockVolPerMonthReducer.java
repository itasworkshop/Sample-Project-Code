package com.StockData;

import java.io.IOException;

import keyvalues.LongPair;
import keyvalues.TextPair;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class AvgStockVolPerMonthReducer extends Reducer<TextPair,LongPair,TextPair,LongPair>{

	private static Long totalVolume= new Long(0);
	private static Long noOfRecords= new Long(0);
	private static Long avgOfRecords= new Long(0);
	private static LongPair result = new LongPair();
	
	protected void reduce(TextPair key, Iterable<LongPair> values,Context context) throws IOException, InterruptedException {
		totalVolume = new Long(0);
		noOfRecords= new Long(0);
		
		
		for (LongPair val : values) {
			totalVolume += val.getFirst().get();
			noOfRecords += val.getSecond().get();
		}
		
		avgOfRecords = totalVolume/noOfRecords;
		result.setFirst(new LongWritable(avgOfRecords));
		result.setSecond(new LongWritable(noOfRecords));
		context.write(key, result);
	}
}
