package com.HBASEProject;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.HBaseAdmin;

public class HBASEmain {
	
	public static void main(String[] args) throws MasterNotRunningException, ZooKeeperConnectionException, IOException{
		
		Configuration conf= HBaseConfiguration.create();
		HBaseAdmin admin = new HBaseAdmin(conf);
		
		HTableDescriptor table= new HTableDescriptor("MyTable1");
		HColumnDescriptor family= new HColumnDescriptor("family1");
		table.addFamily(family);
		
		admin.createTable(table);
	}

}
