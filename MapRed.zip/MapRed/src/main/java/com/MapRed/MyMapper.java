package com.MapRed;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable, Text, Text, LongWritable> {
	
	
    private final static LongWritable countOne = new LongWritable(1);
    private final Text reusableText = new Text();
    private CardParser parser=new CardParser();
    
    @Override
    public void map(LongWritable key, Text value, Context context)
	    throws IOException, InterruptedException {
    	 parser.parse(value.toString());
    	  
         
    	    context.write(new Text(parser.getColourByValue()), countOne);
    	}
    }
 