package com.MapRed;

public class CardParser {
	
	private String colour;
	private String suit;
	private String value;
	
	public void parse(String record){
		String[] records= record.split("\\|");
		colour=records[0];
		suit=records[1];
		value=records[2];
	}
	
	public String getColourByValue(){
		return getColour() +"||"+ getValue();
	}
	
	
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getSuit() {
		return suit;
	}
	public void setSuit(String suit) {
		this.suit = suit;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	

}
