package com.MapRed;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.reduce.IntSumReducer;
import org.apache.hadoop.mapreduce.lib.reduce.LongSumReducer;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class DriverClass extends Configured implements Tool{
public static void main(String[] args) throws Exception {
    int exitcode=ToolRunner.run(new DriverClass(), args);
    System.exit(exitcode);
}

public int run(String[] arg0) throws Exception {
   
	
    Job job =new Job(getConf());
    job.setJarByClass(getClass());
    
    //TextInputFormat.addInputPath(job, new Path(arg0[0]));
    MultipleInputs.addInputPath(job, new Path(arg0[0]), TextInputFormat.class, MyMapper.class);
    MultipleInputs.addInputPath(job, new Path(arg0[1]), TextInputFormat.class, MyMapper.class);
    
    //job.setInputFormatClass(TextInputFormat.class);
   
    TextOutputFormat.setOutputPath(job, new Path(arg0[2]));
    job.setOutputFormatClass(TextOutputFormat.class);

    //job.setMapperClass(MyMapper.class);
    job.setCombinerClass(MyReducer.class);
    job.setReducerClass(MyReducer.class);
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(LongWritable.class);
   
    
    job.setNumReduceTasks(1);
   
    return job.waitForCompletion(true)? 0:1;
}
}