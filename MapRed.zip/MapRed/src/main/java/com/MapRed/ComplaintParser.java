package com.MapRed;

public class ComplaintParser {
	
	    private String Date_Rx;
	    private String Product;
	    private String Sub_Product;
	    private String Issue;
	    private String Sub_issue;
	    private String Cons_comp_narrative;
	    private String Cmpy_pub_response;
	    private String Company;
	    private String State;
	    private String ZIPcode;
	    private String Tags;
	    private String Cons_consent_provided;
	    private String Submitted_via;
	    private String Dt_sent_to_Cmpy;
	    private String Response_to_Coust;
	    private String Timely_response;
	    private String Cons_disputed;
	    private String Comp_ID;
	   
	    public void parse(String record ){
	        String []  records= record.split(",");
	       
	        Date_Rx=records[0];
	        Product=records[1];
	        Sub_Product=records[2];
	        Issue=records[3];
	        Sub_issue=records[4];
	        Cons_comp_narrative=records[5];
	        Cmpy_pub_response=records[6];
	        Company=records[7];
	        State=records[8];
	        ZIPcode=records[9];
	        Tags=records[10];
	        Cons_consent_provided=records[11];
	        Submitted_via=records[12];
	        Dt_sent_to_Cmpy=records[13];
	        Response_to_Coust=records[14];
	        Timely_response=records[15];
	        Cons_disputed=records[16];
	        Comp_ID=records[17];
	       
	    }
	   
	    public String getDate_Rx() {
	        return Date_Rx;
	    }
	    public void setDate_Rx(String date_Rx) {
	        Date_Rx = date_Rx;
	    }
	    public String getProduct() {
	        return Product;
	    }
	    public void setProduct(String product) {
	        Product = product;
	    }
	    public String getSub_Product() {
	        return Sub_Product;
	    }
	    public void setSub_Product(String sub_Product) {
	        Sub_Product = sub_Product;
	    }
	    public String getIssue() {
	        return Issue;
	    }
	    public void setIssue(String issue) {
	        Issue = issue;
	    }
	    public String getSub_issue() {
	        return Sub_issue;
	    }
	    public void setSub_issue(String sub_issue) {
	        Sub_issue = sub_issue;
	    }
	    public String getCons_comp_narrative() {
	        return Cons_comp_narrative;
	    }
	    public void setCons_comp_narrative(String cons_comp_narrative) {
	        Cons_comp_narrative = cons_comp_narrative;
	    }
	    public String getCmpy_pub_response() {
	        return Cmpy_pub_response;
	    }
	    public void setCmpy_pub_response(String cmpy_pub_response) {
	        Cmpy_pub_response = cmpy_pub_response;
	    }
	    public String getCompany() {
	        return Company;
	    }
	    public void setCompany(String company) {
	        Company = company;
	    }
	    public String getState() {
	        return State;
	    }
	    public void setState(String state) {
	        State = state;
	    }
	    public String getZIPcode() {
	        return ZIPcode;
	    }
	    public void setZIPcode(String zIPcode) {
	        ZIPcode = zIPcode;
	    }
	    public String getTags() {
	        return Tags;
	    }
	    public void setTags(String tags) {
	        Tags = tags;
	    }
	    public String getCons_consent_provided() {
	        return Cons_consent_provided;
	    }
	    public void setCons_consent_provided(String cons_consent_provided) {
	        Cons_consent_provided = cons_consent_provided;
	    }
	    public String getSubmitted_via() {
	        return Submitted_via;
	    }
	    public void setSubmitted_via(String submitted_via) {
	        Submitted_via = submitted_via;
	    }
	    public String getDt_sent_to_Cmpy() {
	        return Dt_sent_to_Cmpy;
	    }
	    public void setDt_sent_to_Cmpy(String dt_sent_to_Cmpy) {
	        Dt_sent_to_Cmpy = dt_sent_to_Cmpy;
	    }
	    public String getResponse_to_Coust() {
	        return Response_to_Coust;
	    }
	    public void setResponse_to_Coust(String response_to_Coust) {
	        Response_to_Coust = response_to_Coust;
	    }
	    public String getTimely_response() {
	        return Timely_response;
	    }
	    public void setTimely_response(String timely_response) {
	        Timely_response = timely_response;
	    }
	    public String getCons_disputed() {
	        return Cons_disputed;
	    }
	    public void setCons_disputed(String cons_disputed) {
	        Cons_disputed = cons_disputed;
	    }
	    public String getComp_ID() {
	        return Comp_ID;
	    }
	    public void setComp_ID(String comp_ID) {
	        Comp_ID = comp_ID;
	    }
	   
	}